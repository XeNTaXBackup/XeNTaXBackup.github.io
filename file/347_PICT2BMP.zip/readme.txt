PICT2BMP 1.0
------------
Author: Mr.Mouse/XeNTaX
http://www.xentax.com 

>Version history

This is the first. 

>What?

It's a PICT<>BMP converter.You'll need to have MultiEx Commander installed, to get some run-time dlls. Check below. 


PICT come from certain game called Playboy: The Mansion. 
BMP windows graphic. 

I only used one actual PICT file to figure out the format. 
So, if some PICT files don't work, visit the MultiEx Commander forum. 

http://multiex.xentax.com
http://forum.xentax.com 

>Instructions

Just browse to files that you wish to convert (either BMP or PICT). 
Then double click (or click 'Add' ) to add them to the conversion list. 
If done, click 'Convert' to point to a directory where you want the new files. 

Click 'Remove' to remove the selected one from the list, or 'Clear' to clear the whole list. 


The BMP files should be 8-bit, non-compressed, palette-based (indexed). 

Cheers, 
Mr.Mouse
