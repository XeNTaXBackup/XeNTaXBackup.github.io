#
# Street Fighter 4 EMB Extractor
# by magnum29
#

use strict;

print "Enter an EMB file:\n";
chomp( my $emb = <STDIN> );
$emb =~ s/^"//;
$emb =~ s/"$//;

my $EMB;
open $EMB, "<$emb" or die "Couldn't open $emb: $!\n";
binmode($EMB);


seek $EMB, 0x0c, 0;
my $num_files = readu( $EMB, "I", 4 );

seek $EMB, 0x18, 0;
my $file_addresses_start = readu( $EMB, "I", 4 );
my $file_names_start = readu( $EMB, "I", 4 );


seek $EMB, $file_addresses_start, 0;
my @file_start_address;
my @file_size;
my @file_name_address;
my @file_name;

my $add_offset = 0x20;
for( 0..$num_files-1 ) {
	my ($start, $size) = readu( $EMB, "I2", 8 );
	$start += $add_offset;

	if( $start % 16 != 0 ) {
		$start += 16 - ($start % 16);
		$add_offset += 0x10;
	} 

	push( @file_start_address, $start );
	push( @file_size, $size );
}

@file_name_address = readu( $EMB, "I$num_files", 4 * $num_files );

for my $file_name_address( @file_name_address ) {
	seek $EMB, $file_name_address, 0;
	my $data = getc( $EMB );
	my $full_name = "";
	while( $data ne "\0" && !eof($EMB) ) {
		$full_name .= $data;
		$data = getc( $EMB );
	}
	push( @file_name, $full_name );
}

for my $file_num( 0..$num_files-1 ) {
	seek $EMB, $file_start_address[$file_num], 0;
	my $data;
	read( $EMB, $data, $file_size[$file_num] );
	open O, ">$file_name[$file_num]";
	binmode(O);
	print O $data;
	close O;
}


############################################################################

sub readu {
	my $temp;
	read( $_[0], $temp, $_[2] );
	return unpack( $_[1], $temp );
}

