UnlimitedAmmo = {}
function UnlimitedAmmo:Enable()
  EnableUnlimitedAmmo(true)
  self:Enabled()
end
function UnlimitedAmmo:Disable()
  EnableUnlimitedAmmo(false)
  self:Disabled()
end
export = UnlimitedAmmo
UnlimitedAmmo = nil
