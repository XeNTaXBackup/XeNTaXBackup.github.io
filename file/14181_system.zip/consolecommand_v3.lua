ConsoleCommand = {}
function ConsoleCommand:Create(cbox)
  cbox:RegisterLibrary("Domino/System/LuaLibraries/LuaLibCore.lua")
end
function ConsoleCommand:Init(cbox)
  self.CommandId = nil
end
function ConsoleCommand:ShutDown()
  self:Unregister()
end
function ConsoleCommand:Enable()
  if LuaLibCore:AssertNotNil(self.Name) then
    self.CommandId = CDominoConsoleCommandManager_GetInstance():RegisterConsoleCommand(self.Name, self, "TriggerCommand")
  end
  self:Enabled()
end
function ConsoleCommand:Disable()
  self:Unregister()
  self:Disabled()
end
function ConsoleCommand:Unregister()
  if self.CommandId ~= nil then
    CDominoConsoleCommandManager_GetInstance():UnregisterConsoleCommand(self.CommandId)
    self.CommandId = nil
  end
end
function ConsoleCommand:TriggerCommand(parameter)
  self.Parameter = parameter
  if self.Loop then
    self:Unregister()
  end
  self:Execute()
end
export = ConsoleCommand
ConsoleCommand = nil
