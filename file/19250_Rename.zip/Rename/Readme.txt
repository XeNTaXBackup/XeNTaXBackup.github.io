Please read.

・When you use it for MMD, you change 全ての親 to the センター, and please change the センター to the 下半身.
