EA Graphics Tools 
version: 0.1.0
Date: 3rd of June 2010
Code: Mr.Mouse, The XeNTaX Foundation
Website: XeNTaX Game Research Forum, http://www.xentax.com

Quick manual
------------

1. SSH

	Load SSH: Open a PS2 SSH file in a new window. The new window lists the contents and 
	enables you to unpack each image as raw+palette or BMP. 

	Unpack single SSH: Point to an PS2 SSH file and unpack all images as BMP. 

	Unpack all SSH in folder: Point to a folder and unpack all images from all PS2 SSH files found.

2. BIG

	Unpack all BIG in folder: Point to a folder and unpack all BIG files to a given map. 

3. Palette 

	Flip RGB of palette: Switch Red and Blue values of a 256 colour RGBA file. 

	Convert PS2 palette: Convert a raw EA PS2 palette to a normal Windows BMP 256 colour palette

	
	Create Test palette: Create a new High Colour 256 colour palette for image testing purposes.

4. Help

	About: Show some background info


Special thanks to the author of ImpBIG.exe. 

