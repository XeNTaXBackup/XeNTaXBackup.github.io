Filename: E:\TRADUZIONI\I Fantastici 4\ENG\Game\Data\data_x1.fs
File Size: 99803419
End Position Offset: 99291419
Cut Length: 512000