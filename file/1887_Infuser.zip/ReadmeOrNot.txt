Click the ? button in the program.

-Ize