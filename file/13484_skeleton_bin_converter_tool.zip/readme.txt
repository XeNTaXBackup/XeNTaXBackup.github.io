2017 oct 22 // id-daemon:
-----------------------------------------------------------------------------------------
SleepingDogs.exe - here's your gods tool to split BIN into HKX
infinite_crisis_skeleton.exe - and this old good HKX skeleton tool will make SMDs