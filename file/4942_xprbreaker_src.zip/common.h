#ifndef _COMMON_H_
#define _COMMON_H_

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned int   dword;

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>

#endif