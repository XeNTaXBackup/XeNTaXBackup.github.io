// xprbreaker.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "common.h"


char	outdir[255] = "";
char	indir[255]  = "";
dword	keyTable[0x272];

void initKeyTable(dword seed)
{
__asm {
		push	esi
		lea		ecx, keyTable
		mov		eax, seed
		mov		[ecx], eax	
		mov		eax, 1		
		mov		edx, ecx	
		push	edi
RepeatLoop:	
		mov		esi, [edx]
		mov		edi, esi	
		shr		edi, 1Eh
		xor		edi, esi
		imul	edi, 6C078965h
		add		edi, eax	
		mov		[edx+4], edi
		inc		eax			
		add		edx, 4
		cmp		eax, 270h
		jl		RepeatLoop
		pop		edi
		mov		dword ptr [ecx+9C0h], 1	
		pop		esi
    }
}

dword FetchKey()
{
	__asm
	{
		push	esi
		lea		ecx, keyTable
		mov		esi, ecx
		dec		dword ptr [esi+9C0h]
		jnz		loc_1FF00			
		call	regenKeyTable

loc_1FF00:				
		mov		eax, [esi+9C4h]
		mov		ecx, [eax]
		add		eax, 4
		mov		[esi+9C4h], eax
		mov		eax, ecx
		shr		eax, 0Bh
		xor		ecx, eax
		mov		edx, ecx
		and		edx, 0FF3A58ADh
		shl		edx, 7
		xor		ecx, edx
		mov		eax, ecx
		and		eax, 0FFFFDF8Ch
		shl		eax, 0Fh
		xor		ecx, eax
		mov		eax, ecx
		shr		eax, 12h
		xor		eax, ecx
		pop		esi 
		jmp		done

/////sub ReGenKeyTable////
regenKeyTable:
		push	ebx
		push	esi
		push	edi
		//lea		ecx, keyTable ;//edit
		mov		eax, ecx	;
		mov		dword ptr [ecx+9C0h], 270h ;
		mov		[ecx+9C4h], ecx	;
		mov		esi, 0E3h 
		lea		ebx, [ebx+0]

loc_1FE50:
		mov	edx, [eax+4]
		mov	edi, [eax]
		mov	ebx, [eax]
		xor	edi, edx
		and	edi, 7FFFFFFEh
		xor	edi, ebx
		and	dl, 1
		shr	edi, 1
		neg	dl
		sbb	edx, edx
		and	edx, 9908B0DFh
		xor	edi, edx
		xor	edi, [eax+634h]
		mov	[eax], edi
		add	eax, 4
		dec	esi
		jnz	short loc_1FE50
		mov	esi, 18Ch

loc_1FE85:				; CODE XREF: FnReGenKeyTable+85.j
		mov	edx, [eax+4]
		mov	edi, [eax]
		mov	ebx, [eax]
		xor	edi, edx
		and	edi, 7FFFFFFEh
		xor	edi, ebx
		mov	ebx, [eax-38Ch]
		and	dl, 1
		shr	edi, 1
		neg	dl
		sbb	edx, edx
		and	edx, 9908B0DFh
		xor	edi, edx
		xor	edi, ebx
		mov	[eax], edi
		add	eax, 4
		dec	esi
		jnz	short loc_1FE85
		mov	ecx, [ecx]
		mov	edx, [eax]
		mov	ebx, [eax]
		xor	edx, ecx
		and	edx, 7FFFFFFEh
		xor	edx, ebx
		and	cl, 1
		shr	edx, 1
		neg	cl
		pop	edi
		pop	esi
		pop	ebx
		sbb	ecx, ecx
		and	ecx, 9908B0DFh
		xor	edx, ecx
		xor	edx, [eax-38Ch]
		mov	[eax], edx
		ret
done:
	
	}
}
bool fileexists(char * filepath)
{
	WIN32_FIND_DATA FileData;
	HANDLE hSearch;
	hSearch = FindFirstFile(filepath, &FileData);
	bool result = !(hSearch == INVALID_HANDLE_VALUE);
	if (result) FindClose(hSearch);
	return result;
}


void decodeXPR (char* indir, char* filename, bool force = false)
{
	dword	head[3];
	int		nDword;
	dword   *xprdata;
	FILE	*xprf;
	FILE	*outf;

	char fname[255];
	sprintf (fname,"%s%s",indir,filename);
	xprf = fopen(fname,"rbo");
	fread(&head, sizeof(dword), 3, xprf);
	if (force || (head[0] & 0xFFFFFF00) == 0x306EA300)
	{
		dword seed = head[0] ^ 0x30525058;
		printf("DECODE %s\n", filename);
		printf("\tSeed ID      = %.2x\n", head[0] & 0xFF);
		printf("\tSeed         = %.8x\n", seed );
		printf("\tFilesize     = %d\n",head[1]);
		nDword = (head[1]+3) / 4 -3;
		xprdata = new dword[nDword];
		fread(xprdata, sizeof(dword), nDword, xprf);
		if (nDword>0)
		{
			char outname[255];
			char fnheader[80]="", ext[30]="";
			sscanf(filename, "%[^'.'].%[^'.']", fnheader, ext);
			sprintf(outname,"%s%s~%.2X.%s",outdir,fnheader,head[0] & 0xFF, ext);
			printf("\tNew Filename = %s\n", outname);

			initKeyTable(seed);
			int i;
			for (i=0; i<nDword; i++) xprdata[i] = xprdata[i] ^ (FetchKey() + 0x31415926);
			head[0] = 0x30525058;
			outf = fopen(outname,"wb+");
			fwrite(&head, sizeof(dword), 3, outf);
			fwrite(xprdata, sizeof(dword), nDword, outf);
			fclose(outf);
		}
	} else {
		 printf("\tSkip: Invalided File header\n");
	}
	fclose(xprf);
}

void encodeXPR (char* indir, char* filename, bool force = false)
{
	dword	head[3];
	int		nDword;
	int		i;
	dword   *xprdata;
	FILE	*xprf;
	FILE	*outf;

	char fname[255];
	sprintf (fname,"%s%s",indir,filename);
	xprf = fopen(fname,"rbo");
	fread(&head, sizeof(dword), 3, xprf);

	printf("ENCODE %s\n", filename);
	if (force || (head[0] == 0x30525058))
	{
		char *fh = strtok(filename, "~");
		char *fs = strtok(NULL,".");
		char *fe = strtok(NULL,"\0");
		char outname[255]="";
		dword seed = (strtoul(fs,NULL,16) & 0xFF ^ 0x58) | 0x003cf300;;
		sprintf(outname,"%s%s.%s",outdir,fh,fe);
		i=0;
		while (fileexists(outname))
		{
				sprintf(outname,"%s%d-%s.%s",outdir,++i,fh,fe);
		}		
		printf("\tSeed ID      = %s\n", fs);
		printf("\tSeed         = %.8x\n", seed );
		printf("\tfilesize     = %d\n",head[1]);
		printf("\tNew Filename = %s\n", outname);
		
		nDword  = (head[1]+3) /4 -3;
		if (nDword>0)
		{
			xprdata = new dword[nDword];
			fread(xprdata,sizeof(dword),nDword,xprf);
			initKeyTable(seed);
			for (i=0; i<nDword; i++) xprdata[i] = xprdata[i] ^ (FetchKey() + 0x31415926);
			head[0] = 0x30525058 ^ seed;
			outf = fopen(outname,"wb+");
			fwrite(&head, sizeof(dword), 3, outf);
			fwrite(xprdata, sizeof(dword), nDword, outf);
			fclose(outf);
		}
	} else {
		printf("\tSkip: maybe already encoded!\n");
	}
		
	fclose(xprf);
}

int main(int argc, char* argv[])
{
	WIN32_FIND_DATA FileData;
	HANDLE hSearch;
	BOOL bFinished = FALSE;

	if(argc < 2) { printf("\nUsage: xprbreaker [file.xpr]\n"); exit(1);	}

	int lastdm = (dword)strrchr(argv[1],'\\') - (dword)argv[1];
	if (lastdm > 0) strncpy(indir,argv[1],lastdm+1);
	strcpy(outdir,indir);

	char rpfilename[255]="";
	sprintf(rpfilename,"%sxprReport.txt",outdir);

	hSearch = FindFirstFile(TEXT(argv[1]), &FileData);
	if (hSearch == INVALID_HANDLE_VALUE) { printf("\nNo files found.\n"); return 0; }
	while(!bFinished)
	{
		printf("%s\n",FileData.cFileName); 
		if (strrchr(FileData.cFileName,'~'))
			encodeXPR(indir,FileData.cFileName); 
		else 
			decodeXPR(indir,FileData.cFileName);
		bFinished = !(FindNextFile(hSearch, &FileData));
	}
	FindClose(hSearch);
	return 0;
}
