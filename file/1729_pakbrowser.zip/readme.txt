A .pak browser, unpacker and creator for spellforce 2
By Timeslip (oblivion@timeslipped.co.uk)
Requires .NET 2.0 or mono 1.2 (only tested against mono 1.2.3. Earlier releases may or may not work.)

-------------
--- Usage ---
-------------

Use 'open' to open existing pak files and 'create' to create a new one.

'Unpack selected' unpacks whichever files are selected in the file list. 'Unpack all' unpacks the whole archive.

Double click on a single file in the file list to extract it to your temp folder and open it in whatever your default viewer for that file type is. (Or in notepad, if the file type has no default viewer.)

You can select multiple files using the normal explorer controls. (i.e. hold shift to select a consecutive set of files, or control to select multiple disjoint files.)

---------------
--- History ---
---------------

1.0.1
Fixed: A text encoding issue. (Responsible for the crash when trying to browse sf2_base11.pak)
Fixed: A crash when double clicking a file with no default handler associated.
       (Will now open in notepad if under 256K in size, or display an error otherwise)
Fixed: Crash if you closed the program while previewing a file which the default viewer had
       write locked.
Tweak: Removed the close button. Paks are now closed automatically when you try to open a
       new one.

--------------
1.0.0
Initial release