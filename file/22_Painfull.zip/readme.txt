PainFull Extractor 
Done in 2004 by Mike Zuurman
AKA Mr.Mouse/XeNTaX

*Purpose

Small archiver to extract stuff (and import files one by one) 
into *.PAK files from the Painkiller game by DreamCatchers. 
Use this for domestic purposes only ! It's a tool for the standard
fan of the game that just wants to mess about with some of the
resources. 

>>>> Remember and respect the authors' copyrights on these files! <<<<

If you want to do something big, be sure to contact them first. 

*Installation
Install MultiEx Commander (http://multiex.xentax.com) first,
you may not need it, but it will ensure you have dlls that you're gonna need.

Then install the all the files in this zip file in one directory of your choice. 

Start with Painfull.exe

*Manual

Just browse to a PAK file of your choice at the left side 
of the tool, select it in the file-list, and hit "Open Painkiller PAK". 
You will notice the contents (entries) listed to the right. 

- Extraction 
  Just select all files at once, clicking on the top file first 
  followed by a click on the last while holding down shift. 
  Alternatively just select the files you want, by holding ctrl. 
  
  To extract, click the button below and in between the two lists, 
  with "<<" on it. Voila. It will extract the files into the current path. 

- Replacement
  Select a file in the file list that you want to use to replace a file 
  in the open archive. Second, select the file you wish to replace in the 
  contents list. Click the ">>" button, and wait until it's finished. 
  Done. 
  
  Important Note! PainFull will automatically import the new file, and will 
  NOT create a backup. If you want to mess around with any PAK file, 
  be sure to back it up first and store it somewhere save!

( http://www.xentax.com, 2004 )
 
 Thanks to Mambox for the initial hint! :)





