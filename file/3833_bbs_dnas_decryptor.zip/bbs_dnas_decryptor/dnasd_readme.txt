DNAS Decryptor for JP version:
  Originally developed by Liquidzigong (Hrimfaxi)
DNAS Decryptor for US/EU/FM version:
  Modded by Xeeynamo


HOWTO:
Put BBS1.DAT, BBS2.DAT and BBS3.DAT on ms0:/ and launch the dnas decryptor.
Output files will be BBS1_DEC.DAT etc