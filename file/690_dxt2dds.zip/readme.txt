DXT2DDS version 0.0.6
---------------------
Author: Mike W. Zuurman
XeNTaX 2006
http://forum.xentax.com 

This program was created by request at the XeNTaX MultiEx Commander forums. 

http://multiex.xentax.com

---------------------

The program takes MX vs ATV Unleashed (PC) DXT files and converts them to DXT1 or DXT3 DDS files. Note that perhaps not all of the DXT format is completely supported. 
Any info is welcome if you find out more. 

The program is easy to use : just select a number of files to convert to DDS (or DDS to convert to DXT). 

Cheers, and please support the MultiEx Project and become a Friend of MultiEx! 

Best, 

Mr.Mouse/XeNTaX
http://www.xentax.com 
