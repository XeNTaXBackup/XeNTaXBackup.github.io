So blonde data file unpacker v1.0

Perl script for unpacking/extracting datafiles used in "So blonde" by
Anaconda. Based on the file spec found at:
http://forum.xentax.com/viewtopic.php?f=10&t=3024


The archive should contain:
  This README.txt file.
  unpack.pl, the script.

You will also need:

Perl, see http://www.activestate.com for a free installer.
(http://www.activestate.com/store/activeperl/download/)

The Path::Class module, to install this for activestate perl, run the
command:
cpanp install Path::Class
and wait for it to finish.

You may also run this code on a Mac or Linux machine if it has read access
to the So Blonde files.

To install:

Unpack the contents of this archive into a directory on your hard
disk. Eg. C:\soblondeunpacker.

To run:

Change to the So Blonde install directory, for example:
cd "D:\Program Files\ANACONDA\So Blonde"

Run the script:
perl C:\soblondeunpacker\unpack.pl --help

The help option will tell you how to use the script.

-=- James Mastros, james@mastros.biz, August 10th, 2008 -=-



