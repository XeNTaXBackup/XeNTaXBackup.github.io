#!/usr/bin/perl
use warnings;
use strict;
use Path::Class;
use Getopt::Long;
$|=1;

print "So blonde data file unpacker v1.0\n\n";

my $help = 0;
my $DEBUG = 0;
my $force = 0;
my $savedir = '.';
my $optres = GetOptions("help" => \$help,
                        "debug" => \$DEBUG,
                        "force" => \$force,
                        "savedir:s" => \$savedir,
                       );
usage() if($help);
require Data::Dump::Streamer if $DEBUG;

my $infilename = shift || 'Data/soblonde';

if(!-e "$infilename.toc") {
  print "File $infilename.toc not found.\n\n";
  usage();
}

open my $toc_fh, '<:raw', "$infilename.toc"
  or die "Can't open $infilename.toc: $!";
open my $dir_fh, '<:raw', "$infilename.dir"
  or die "Can't open $infilename.dir: $!";
open my $dat_fh, '<:raw', "$infilename.dat"
  or die "Can't open $infilename.dat: $!";
(my $toc, $toc_fh) = eat_toc_file($toc_fh);
print "\n";
#Dump $toc;
eat_dir_file($dir_fh, $toc);
#Dump $toc;
dump_dat_file($dat_fh, $toc);

sub usage {
  print << "USAGE";
  Three files are required by this unpacker, a .toc, .dir and .dat
  To run it, pass as an argument the path and basename of the file.
  The default is 'Data\\soblonde', to use the default, run the script from the
  'Program Files\\ANACONDA\\So Blonde' directory. To run from elsewhere, pass the directory, eg:

  $0 <options> "Program Files\\ANACONDA\\So Blonde\\Data\\soblonde"

  Other options:
    --help          - show this help message and exit
    --debug         - output debugging messages during file extaction
    --force         - overwrite files if they already exist
    --savedir <dir> - directory to save extracted files to, default is the current dir

  NOTE: Make sure you use quotes if the paths contain spaces.
USAGE

  exit(0);
}

sub eat_dir_file {
  my ($fh, $toc) = @_;
  for my $rest_ent (@{$toc->{by_id}{REST}{offset_data}}) {
    (my $name_offset, $fh) = Binary::eat_desc($fh, 'V');
    ($rest_ent->{name}, $fh) = Binary::eat_at($fh, $name_offset, 'Z*');
  }
  return ($toc, $fh);
}

sub dump_dat_file {
  my ($fh, $toc) = @_;
  for my $rest_ent (@{$toc->{by_id}{REST}{offset_data}}) {
    my $name = file($savedir, $rest_ent->{name});
    next if(-e "$name" and not $force);
    # Don't error-check here, errors are likely "exists", and will show up when opening output file anyway.
    $name->dir->mkpath(1);
    print "Extracting $name\n";
    (my $data, $fh) = Binary::eat_at($fh, $rest_ent->{ofsStart}, 'a'.$rest_ent->{ofsLenReal});
    open my $outfh, ">:raw", $name
      or die "Couldn't open $name: $!";
    print $outfh $data;
  }
  return ($toc, $fh);
}

sub eat_toc_file {
  my ($fh) = @_;
  my $toc;
  while (!eof($fh)) {
    (my $entry, $fh) = eat_toc_chunk($fh);
    push @{$toc->{sub_toc}}, $entry;
    $toc->{by_id}{$entry->{ChunkID}} = $entry;
    #Dump $entry;
  }
  return ($toc, $fh);
}

sub eat_toc_chunk {
  my ($fh) = @_;
  (my $chunk, $fh) = Binary::eat_desc($fh, [
                                            ChunkID => 'a4',
                                            Version => 'V',
                                            DataSize => 'V',
                                            DataCount => 'V',
                                            unk1 => 'V',
                                            unk2 => 'V',
                                            unk3 => 'V',
                                            unk4 => 'V',
                                           ]);
  #Dump $chunk;
  my $chunk_len = ($chunk->{DataCount} and ($chunk->{DataSize}/$chunk->{DataCount}));
  # Size of a TOC chunk is 32 bytes, assume subchunks are always homogenius.
  print "Chunk len: $chunk_len\n" if($DEBUG);
  if (!$chunk_len) {
    # Do nothing.
  } elsif ($chunk_len == 32) {
    for (0..$chunk->{DataCount}-1) {
      (my $sub_chunk, $fh) = eat_toc_chunk($fh);
      push @{$chunk->{sub_toc}}, $sub_chunk;
      $chunk->{by_id}{$sub_chunk->{ChunkID}} = $sub_chunk;
    }
  } elsif ($chunk_len == 12) {
    for (0..$chunk->{DataCount}-1) {
      (my $sub_chunk, $fh) = eat_offset_chunk($fh);
      push @{$chunk->{offset_data}}, $sub_chunk;
      #print time;
      print '.' if not $_ % 100 and $DEBUG;
    }
    print "\n" if $DEBUG;
  }
  return ($chunk, $fh);
}

sub eat_offset_chunk {
  my ($fh) = @_;
  my ($ofs) = Binary::eat_desc($fh, [unk1 => 'V',
                                     ofsLen => 'V',
                                     ofsStart => 'V']);
  $ofs->{ofsLenLow} = $ofs->{ofsLen} & 0b11;
  $ofs->{ofsLenReal} = $ofs->{ofsLen} >> 2;
  return ($ofs, $fh);
}

package Binary;
use warnings;
use strict;
use Encode 'decode';

sub eat_desc {
  my ($fh, $desc) = @_;

  # print "In eat_desc, desc=$desc\n";

  my $ret = {};
  if (ref $desc eq 'ARRAY') {
    # *COPY*
    my @desc = @$desc;
    while (@desc) {
      my ($name, $subdesc) = splice(@desc, 0, 2, ());
      # printf "Eating %s type %s at 0x%x\n", $name, $subdesc, tell($fh);
      ($ret->{$name}, $fh) = eat_desc($fh, $subdesc);
    }
    return ($ret, $fh);
  } elsif (not ref $desc) {
    my ($len, $template);
    my %plain = ('Q>' => 8,
                 'f>' => 4,
                 N => 4,
                 n => 2,
                 V => 4,
                 v => 2,
                 c => 1,
                 C => 1,
                );
    if (exists $plain{$desc}) {
      return eat_unpack($fh, $desc, $plain{$desc});
    } elsif ($desc eq 'Z*') {
      # FIXME: condition should check if fh is a filehandle or a string.
      $ret = '';
      while (1) {
        my $char = my_read($fh, 1);
        # print "Z* reading: '$char'\n";
        if ($char eq "\0") {
          return (decode('ascii', $ret), $fh);
        } else {
          $ret .= $char;
        }
      }
    } elsif ($desc =~ /^(a|Z)(\d+)$/) {
      return eat_unpack($fh, $desc, $2);
    } else {
      die "Don't know what to do with stringy/unpack desc '$desc' in eat_desc";
    }
  } elsif (ref $desc eq 'CODE') {
    return $desc->($fh);
  } else {
    die "Don't know what to do with descriptor $desc";
  }
}

sub eat_unpack {
  my ($fh, $template, $len) = @_;
  return (unpack($template, my_read($fh, $len)), 
          $fh);
}

sub my_read {
  my ($fh, $length) = @_;
  $/=\$length;
  return '' if !$length;
  die "EOF!" if eof $fh;
  my $data = <$fh>;
  die "Can't read: $!" if not defined $data;
  die "Short read: $!" if length($data) != $length;
  return $data;
}

sub eat_at {
  my ($fh, $pos, $desc) = @_;
  my $origpos = tell($fh);
  seek($fh, $pos, 0);
  (my $data, undef) = Binary::eat_desc($fh, $desc);
  seek($fh, $origpos, 0);
  return ($data, $fh);
}

1;
