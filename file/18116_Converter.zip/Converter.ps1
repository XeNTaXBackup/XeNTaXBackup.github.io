function ConvertTo-BinaryString {
    # converts the bytes of a file to a string that has a
    # 1-to-1 mapping back to the file's original bytes. 
    # Useful for performing binary regular expressions.
    [OutputType([String])]
    Param (
        [Parameter(Mandatory = $True, ValueFromPipeline = $True, Position = 0)]
        [ValidateScript( { Test-Path $_ -PathType Leaf } )]
        [String]$Path
    )

    $Stream = New-Object System.IO.FileStream -ArgumentList $Path, 'Open', 'Read'

    # Note: Codepage 28591 returns a 1-to-1 char to byte mapping
    $Encoding     = [Text.Encoding]::GetEncoding(28591)
    $StreamReader = New-Object System.IO.StreamReader -ArgumentList $Stream, $Encoding
    $BinaryText   = $StreamReader.ReadToEnd()

    $StreamReader.Close()
    $Stream.Close()

    return $BinaryText
}

$files = Get-ChildItem . *.wem -rec
foreach ($file in $files)
{
  $inputFile  = $file.FullName
  $outputFile = $file.FullName
  $fileBytes  = [System.IO.File]::ReadAllBytes($inputFile)
  $binString  = ConvertTo-BinaryString -Path $inputFile

  $re = [Regex]'(?s)^.*?(?=\x52\x49\x46\x46)'

  # use a MemoryStream object to store the result
  $ms  = New-Object System.IO.MemoryStream
  $pos = $replacements = 0

  $re.Match($binString) | ForEach-Object {
    # write the part of the byte array before the match to the MemoryStream
    $ms.Write($fileBytes, $pos, $_.Index)
    # update the 'cursor' position for the next match
    $pos += ($_.Index + $_.Length)
    # and count the number of replacements done
    $replacements++
  }

  # write the remainder of the bytes to the stream
  $ms.Write($fileBytes, $pos, $fileBytes.Count - $pos)
  
  # save the updated bytes to a new file (will overwrite existing file)
  [System.IO.File]::WriteAllBytes($outputFile, $ms.ToArray())
  $ms.Dispose()
  
  if ($replacements) {
    Write-Host "$replacements replacement(s) made."
  }
  else {
    Write-Host "Byte sequence not found. No replacements made."
  }
}