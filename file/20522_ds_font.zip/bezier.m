% this function creates N coordinates of a bezier curve made from the
% points (x,y)
function [xx,yy] = bezier(x,y,N)
    pts = [x;y];

    n = numel (x) - 1;
    t = linspace (0, 1, N);
    bez = zeros (2, N);
    for i = 0 : n
        bez = bez + kron(nchoosek (n,i) * (1-t).^(n-i).*t.^i, pts(:,i+1));
    end
    
    xx = bez(1,:);
    yy = bez(2,:);
end