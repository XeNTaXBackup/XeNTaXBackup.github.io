function FONT = readfont (fp)
    fread (fp, 12, 'char'); %scrap header
    fread (fp, 16, 'char'); %scrap font hash
    
    FONTname_length = fread (fp, 1, 'uint32');
    
    fread (fp, 1, 'uint32'); %unk
    
    FONT.name =  [char (fread (fp, FONTname_length, 'char'))'];
    
    FONT.unitsForEm = fread (fp, 1, 'single'); %unitsForEm: number of units on the em square
    FONT.ascent     = fread (fp, 1, 'single'); %ascent: max positive height of font
    FONT.descent    = fread (fp, 1, 'single'); %descent: max negative height of font - for letters like 'j'
    FONT.capHeight  = fread (fp, 1, 'single'); %capHeight: height of uppercase glyphs
    
    FONT.numberOfGlyphs = fread (fp, 1, 'uint32');
    
    for i = 1 : FONT.numberOfGlyphs
        GLYPH = readglyph (fp);
        GLYPH.index = i; 
        
        %copy glyph in font
        fields = fieldnames(GLYPH);
        for j = 1 : numel(fields)
            FONT.glyph(i).(fields{j}) = GLYPH.(fields{j});
        end
    end
end