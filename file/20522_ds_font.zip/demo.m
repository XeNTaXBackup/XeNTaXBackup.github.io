close all

fp = fopen('fonts\interface\fonts\ds\expsmediumneon.core');
FONT = readfont (fp);

% print all the font table
figure;
hold on;
daspect([1 1 1]);

xlast = 0;
ylast = 0;

n = round (sqrt (FONT.numberOfGlyphs));
for i = 1 : FONT.numberOfGlyphs
    glyph = FONT.glyph(i);
    % get coordinates of outlines
    [xx,yy] = renderchar (glyph);
    
    % extract data from glyph
    advance      = glyph.advance;
    leftBearing  = 0;
    rightBearing = glyph.advance - glyph.xMax;
    width        = glyph.xMax - glyph.xMin;
    height       = glyph.yMax - glyph.yMin;
    
    xx = xlast + xx + leftBearing;
    yy = ylast + yy;
    % plot the glyph
    plot(xx, yy, 'b');
    
    % plot glyph boxes
    if (numel (xx) ~= 0)
        rectangle('Position', [xlast + glyph.xMin ylast - FONT.descent width   FONT.unitsForEm]);
        rectangle('Position', [xlast              ylast - FONT.descent advance FONT.unitsForEm]);
    else
        rectangle('Position', [xlast              ylast - FONT.descent advance FONT.unitsForEm]);
    end
    
    % move "cursor" for the next glyph
    if (numel (xx) ~= 0)
        xlast = max (xx) + rightBearing;
    else
        xlast = xlast + advance;
    end
    
    % "carriage return" for the next row of glyphs
    if (mod (i, n) == 0)
        ylast = ylast - FONT.unitsForEm;
        xlast = 0;
    end
end

% print a sentence
figure;
hold on;
daspect ([1 1 1]);

string = 'Hello World!';

xlast = 0;
ylast = 0;

for i = 1 : numel (string)
    % find glyph to print
    index = (char (FONT.glyph(:).symbol) == string(i));
    glyph = FONT.glyph(index);
    % get coordinates of outlines
    [xx,yy] = renderchar (glyph);
    
    % extract data from glyph
    advance      = glyph.advance;
    leftBearing  = 0;
    rightBearing = glyph.advance - glyph.xMax;
    width        = glyph.xMax - glyph.xMin;
    height       = glyph.yMax - glyph.yMin;
    
    xx = xlast + xx + leftBearing;
    yy = ylast + yy;
    % plot the glyph
    plot (xx, yy, 'b');

    % move "cursor" for the next glyph
    if (numel (xx) ~= 0)
        xlast = max (xx) + rightBearing;
    else
        xlast = xlast + advance;
    end
end

fclose (fp);

% % for "debug" purposes
% xlim([0 advance])
% for ii = 1:numel(glyph.contour(1).xCoordinates)
%     text(glyph.contour(1).xCoordinates(ii),glyph.contour(1).yCoordinates(ii),num2str(ii),'Color','r','FontSize',11)
% end
% 
% rectangle('Position', [glyph.xMin ylast + glyph.yMin width   height]);
% rectangle('Position', [0          ylast + glyph.yMin advance height]);