function svgdata = outlineToSVG(glyph,ascent)
    svgdata = [];
    
    for t = 1 : glyph.numberOfContours
        LINEdata = glyph.contour(t).linedata;
        X = glyph.contour(t).xCoordinates;
        Y = ascent-glyph.contour(t).yCoordinates; %minus sign according to standard SVG graphics
        
        %moveto
        svgdata = [svgdata 'M'];

        i = 1;
        svgdata = [svgdata num2str(X(i)) ',' num2str(Y(i))];
        for l = 1 : numel (LINEdata)
            %0x40 = 64
            %check if NOT bezier (pp contains the number of points to join)       
            if (bitand (LINEdata(l), 64) == 0)
                %it's a straight line
                pp = LINEdata(l);

                for j = i+1 : i+pp
                    %lineto
                    svgdata = [svgdata ' L' num2str(X(j)) ',' num2str(Y(j))];
                end
                
                i = i + pp;
            else
                %it's a bezier curve
                pp = LINEdata(l) - 64;

                %quadratic bezier with mean position points as used in TTF
                %fonts
                for p = i+1 : i+pp-2    %only on control points
                    XP = mean([X(p), X(p+1)]);
                    YP = mean([Y(p), Y(p+1)]);
                    
                    svgdata = [svgdata ' Q' num2str(X(p)) ',' num2str(Y(p)) ' ' num2str(XP) ',' num2str(YP)];
                end
                XP = X(i+pp);
                YP = Y(i+pp);
                
                svgdata = [svgdata ' Q' num2str(X(i+pp-1)) ',' num2str(Y(i+pp-1)) ' ' num2str(XP) ',' num2str(YP)];
                
                i = i + pp;
            end
        end

        %closepath
        svgdata = [svgdata ' Z'];
    end
end