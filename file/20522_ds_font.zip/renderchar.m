% this function creates the sequence of coordinates from the information of
% the glyph, namely the "line data" and the sequence of points contained in
% the "outline data"
function [xx,yy] = renderchar (CHAR)
    bezierPoints = 50;  %number of points for the bezier curves

    xx = [];
    yy = [];

    for t = 1 : CHAR.numberOfContours
        LINEdata = CHAR.contour(t).linedata;
        X = CHAR.contour(t).xCoordinates;
        Y = CHAR.contour(t).yCoordinates;
        
        i = 1;
        for l = 1 : numel (LINEdata)
            %0x40 = 64
            %check if NOT bezier (pp contains the number of points to join)       
            if (bitand (LINEdata(l), 64) == 0)
                %it's a straight line
                pp = LINEdata(l);

                %plot (X(i:i+pp), Y(i:i+pp), 'b');
                xx = [xx, X(i:i+pp)];
                yy = [yy, Y(i:i+pp)];
                i = i + pp;
            else
                %it's a bezier curve
                pp = LINEdata(l) - 64;

                %quadratic bezier with mean position points as used in TTF
                %fonts
                XP1 = X(i);
                YP1 = Y(i);
                for p = 1 : pp-2    %only on control points
                    XP2 = mean([X(i+p), X(i+p+1)]);
                    YP2 = mean([Y(i+p), Y(i+p+1)]);
                    
                    [xb, yb] = bezier ([XP1, X(i+p), XP2], [YP1, Y(i+p), YP2], bezierPoints);
                    xx = [xx, xb];
                    yy = [yy, yb];    
                    
                    XP1 = XP2;
                    YP1 = YP2;
                end

                XP2 = X(i+pp);
                YP2 = Y(i+pp);
                [xb, yb] = bezier ([XP1, X(i+pp-1), XP2], [YP1, Y(i+pp-1), YP2], bezierPoints);
                xx = [xx, xb];
                yy = [yy, yb]; 
                
                i = i + pp;
            end
        end
        
        %add last segment to close shape
        xx = [xx, X(end), X(1)];
        yy = [yy, Y(end), Y(1)];

        %add NaNs to disjoint multiple outlines
        xx = [xx, NaN];
        yy = [yy, NaN];
    end
end