fp = fopen('fonts\interface\fonts\ds\sst.core');
FONT = readfont (fp);
filename = [FONT.name '.svg'];

docNode = com.mathworks.xml.XMLUtils.createDocument ('svg');
svg = docNode.getDocumentElement;
svg.setAttribute ('version', '1.1');
svg.setAttribute ('width',   '100%');
svg.setAttribute ('height',  '100%');

defs = docNode.createElement ('defs');
svg.appendChild (defs);

font = docNode.createElement ('font');
defs.appendChild (font);

font_face = docNode.createElement ('font-face');
font_face.setAttribute ('font-family',           FONT.name);
font_face.setAttribute ('units-per-em', num2str (FONT.unitsForEm));
font_face.setAttribute ('ascent',       num2str (FONT.ascent));
font_face.setAttribute ('descent',      num2str (FONT.descent));
font_face.setAttribute ('cap-height',   num2str (FONT.capHeight));

font_face.setAttribute ('vert-origin-y','0');

font.appendChild(font_face);

for i = 1 : FONT.numberOfGlyphs
    g = FONT.glyph(i);
    
    glyph = docNode.createElement ('glyph');
    glyph.setAttribute ('unicode', g.symbol);
    glyph.setAttribute ('horiz-adv-x', num2str (g.advance));
    font.appendChild (glyph);
    
    path = docNode.createElement('path');
    path.setAttribute('d', outlineToSVG (g,FONT.ascent));
    glyph.appendChild (path);
end

xmlwrite (filename, docNode);
fclose (fp);