function GLYPHdata = readglyph (fp)
    %glyph information
    GLYPHdata.advance = fread (fp, 1, 'single');
    GLYPHdata.symbol  = char (fread (fp, 1, 'uint32'));
    GLYPHdata.xMin    = fread (fp, 1, 'single');
    GLYPHdata.yMin    = fread (fp, 1, 'single');
    GLYPHdata.xMax    = fread (fp, 1, 'single');
    GLYPHdata.yMax    = fread (fp, 1, 'single');
    
    %tracks data
    GLYPHdata.numberOfContours = fread (fp, 1, 'uint32');
    
    for i = 1 : GLYPHdata.numberOfContours
        LINEdata_length = fread (fp, 1, 'uint32');
        
        GLYPHdata.contour(i).linedata = fread (fp, LINEdata_length, 'char');
        
        CONTOURdata_length = fread (fp, 1, 'uint32');
        
        for j = 1 : CONTOURdata_length
            GLYPHdata.contour(i).xCoordinates(j) = fread (fp, 1, 'single');
            GLYPHdata.contour(i).yCoordinates(j) = fread (fp, 1, 'single');
        end
    end
end