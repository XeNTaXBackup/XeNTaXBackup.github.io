Tre Archiver 1.0.3 
By XeNTaX' M.W.Zuurman 2006

Fixed stupid bugs again. Now it should all work as intended. 

History:
--------

Tre Archiver 1.0.2 

Fixed stupid bugs. Now files should open properly. 
Double-clicking should allow previews. 

Tre Archiver 1.0.1 

Made the contents list alphabetical and shiny

Tre Archiver 1.0.0 

Part of the ongoing MultiEx Commander project
Thus, especially for Friends of MultiEx!

Should now be able to open TOC files (and referred TRE files)
Use at your own risk. No warranties!!

Tre Archiver 0.7.16 
By XeNTaX' M.W.Zuurman (aka Mr.Mouse)

- Fixes failed save of resources when compression method is 0
- adds some debug log entries


TRE Archiver 0.7.15


Alpha version

Installation Issues:

This should work if you installed MultiEx Commander as well. 
Get it at http://www.xentax.com

Features

- Open TRE
- Create TRE
- Extract single file
- Extract ALL Files 
- Replace files
- View files

Read the short manual inside. 

Does NOT support Version 0004 TRE's, or compression method 1.


