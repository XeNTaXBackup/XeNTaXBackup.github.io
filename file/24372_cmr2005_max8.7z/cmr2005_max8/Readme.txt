cmr2005 track impoerter for 3dsmax8 (may work with ver 7 and 9 but not tested);

install:
	- copy "_max_cmr2005.dlu" max plugin folder, usually "\Program Files\Autodesk\3dsMax8\plugins\";
	- this is a utility plugin so press "the hammer", press "Configure buttons Set",
	  locate and drag "_max_cmr2005" to any of the buttons in util's rollout;

usage:
	1. decompress and extract:
		- press button "DEC_EXTR" and select any of TBF, PFX, PFX, T0X, T1X, T2X files;
		  TBF - texture pack
		  T2X - contain main files for ground and tree walls, some spectators too
		  T1X - contains ITAGs, ITAGs contains cloned objects;
		- any of those archives will be decmpressed first then content will be extracted
		  in a new folder wich will be created near and with the same name as the selected file;
	
	2. import ground:
		- press "TAS" button and select TAS, TAN or SH2 from the decompressed T2X, one at a time;

	3. import clones:
		- press "ITAGs" button and select ITAGs files from the decompressed T1X, multiple file selection supported;


notes:
	- transparency and vertex color is not handeled;
	- Set "Force 2 sided" in viewport options but becarefull, alot of objects my need normal flipping;

have fun :)
