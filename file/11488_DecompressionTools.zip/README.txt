Ok. Before I start this tutorial I have to let you know I knew nothing about DepthMaps, ColorMaps,
PolyMaps, until a friend A.Bullet asked me to make these tools so everything I�m going to tell you that has to do with them is what I learned from him.


CPT DepthMap Stripper:
This program is a self contained program does not need the game in anyway. 
To use it you have to extract the CPT files from the resource.pff file. 
Then you run the Stripper program. Select any CPT file or even all the CPT files at once. 
It will create .raw files based off the name of the CPT. 
For example Dvxc1.cpt would make a file called Dvxc1.raw in the same directory as the CPT file.

You can open these with Photoshop.
If you do it will pop up with a screen requesting info. This is the info you need to put.
The dimensions are 1024x1024 Count 2 and interleaved.

A.Bullet found out that you can edit the JO CPT files and replace the CDEP section with the Raw file dumped.. 
So with a hex editor open the CPT file. Then create a new file.. 
COPY from the start of the program down to CDEP. Paste it into your new file. 
If you copied the CDEP name as well just rename it to DPTH. 
If you didn�t press the Insert Key and type in DPTH at the bottom of your new file. 
Next open the RAW file with the hex editor press CTRL+A then CTRL+C that will select all and copy. 
Then go back to the new file go to the very bottom and press CTRL+V that will past the raw file to 
the bottom of the new file. 
Now go back to the CPT file and search for the word POLY. 
Now copy including the POLY to the very bottom of the file and the paste it to the very bottom of your new file. 
Now save the New file as the CPT name you want. This will make it so that BHD or even the BHD med can read it.

CPT Poly Dumper:
This is not a self contained program it requires JO version 1.2.0.10 to work. 
This is a loader so you need to place the exe and the DLL into the same folder as the game. 
Then you have to run it by the exe that is in the zip. 
It will dump the Poly Map of CPT of the map you load in the game. It will dump it to C:\RawDumps

You can open these with Photoshop.
If you do it will pop up with a screen requesting info. This is the info you need to put.
The dimensions are 1024x1024 Count 4 and interleaved.

Right now I don�t have a converter to put the poly maps back to how they can be read by the game. 
Maybe someone else can figure that out or give me time. 
Or maybe the game can use raw poly maps and maybe poly needs to be renamed to something not sure yet.

BFC1 Dumper:
This is not a self contained program it requires JO version 1.2.0.10 to work. 
This is a loader so you need to place the exe and the DLL into the same folder as the game. 
Then you have to run it by the exe that is in the zip. 
It will dump all image base compressed files in the map you load. DDS, MDT, TGA, ECT. 
It will dump it to C:\TGADumps

This also includes the Color Maps and the tiles that the med can use


