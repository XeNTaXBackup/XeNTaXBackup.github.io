  ClipMon 1.1
===============
(C) 2003 XeNTaX
www.xentax.com
===============

ClipMon is a basic screenshot grabber. 

WHat it does is grab the contents of the Windows Clipboard if a bitmap is put onto it. This is for instance the case whenever the PrintScreen (PRTSCN) key is pressed. 
It can then show this in a box and/or save it as a BitMap. 

Options:

[] Automatically Show the Picture in a (Pre)view Box
[] Autosave a new PRTSCN instance. Will create unique filenames
   *Note: The default directory is tha application path
[] Set output directory, thus sets the directory to output the new pictures on the clipboard as a .BMP


You may also choose "Save BMP..." from the FIle menu, if the current picture is of your liking and you'd like to save it using your own defined filename. 

Note also that you can resize the Application Window at any time. 



