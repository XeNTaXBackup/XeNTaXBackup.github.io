
DXT2DDS version 0.0.7
---------------------
Author: Mike W. Zuurman
XeNTaX 2006
http://forum.xentax.com 

This program was created by request at the XeNTaX MultiEx Commander forums. 

http://multiex.xentax.com

---------------------

The program takes MX vs ATV Unleashed (PC) DXT files and converts them to DXT1 or DXT3 DDS files. Note that perhaps not all of the DXT format is completely supported. 
Any info is welcome if you find out more. 

The program is easy to use : just select a number of files to convert to DDS (or DDS to convert to DXT). 

COMMAND LINE OPTIONS: dxt2dds ($file to convert)?($destination name (optional))
The program will check whether the file to convert is a DDS file, if so it will convert it to DXT, if not it will attempt to convert the file to DDS. Note the '?' between the filename and
the destination name. This is obligator if you wish to specify the destination name yourself. Leave it out (and don't specify a destination name) if you don't.
 
EXAMPLE: dxt2dds test.dxt?test_converted.dds


Cheers, and please support the MultiEx Project and become a Friend of MultiEx! 

Best, 

Mr.Mouse/XeNTaX
http://www.xentax.com 
