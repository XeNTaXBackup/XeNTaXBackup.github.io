#include <iostream>
#include <fstream>
#include <fcntl.h>
#include <string>
#include <sstream>
#include <sys/stat.h>
#include <cstring>
#include "lib/lz4.h"

using namespace std;

/**
 * A lot of the code you see here is inspired by some previous work I found here:
 * https://epw14.wordpress.com/2015/12/24/artifex-mundi-cube/ . This code didn't
 * extract the textures, but did include instructions for handling the XOR conversion
 * in the CUB archives. The header and entry code had to be updated too.
 *
 * For the lz code, you will need to download: https://github.com/lz4/lz4
 */

// The file types that can be processed by this code. Supported types are
// CUB and STEX, with UNKNOWN to denote all others.
enum FILE_TYPE {
	CUB,
	STEX,
	UNKNOWN
};

// All, or at least most Artifex Mundi games are XOR'd with this key.
const unsigned char XOR_KEY = 0x96;

// The size in bytes of the destination raw texture file. To get this
// number, create a sample DDS file of the desired size. Currently set
// for a texture of size 2048x2048.
const int TEXTURE_FILESIZE = 4194304;

// The header for CUB archives. Contains important information like the
// number of entries needed to be extracted,
struct CUB_HDR {
	char cubHeader[4];
	char version[4];
	short entryCount;
	char empty[2];
	char headerComment[256]; // Typically the string "Paczka danych CUBE"
};

// The entry of each given file in the CUB. For version 1.0 the offset and
// length are in Little Endian ordering. For version 1.1, they are in Big
// Endian ordering.
struct CUB_ENTRY_1_1 {
	unsigned char filename[256];
	unsigned long offset;
	unsigned long length;
};

struct CUB_ENTRY_1_0 {
	unsigned char filename[256];
	unsigned char offset[4];
	unsigned char length[4];
};

/**
 * Gets the first 4 bytes from the given file and tries to determine if the file
 * is a CUB or STEX; then resets the seek head.
 */
FILE_TYPE getFileType(FILE* fd) {
	unsigned char magicWord[5]; // Up to 4 letter magic word plus null byte.

	fread(magicWord, sizeof(unsigned char), 4, fd);
	magicWord[4] = '\0';

	// Reset the read head back to byte 0x0
	fseek(fd, 0, SEEK_SET);

	if(strcmp((char*)magicWord, "STEX") == 0) {
		return STEX;
	}

	magicWord[0] ^= XOR_KEY;
	magicWord[1] ^= XOR_KEY;
	magicWord[2] ^= XOR_KEY;
	magicWord[3] ^= XOR_KEY;

	if(strcmp((char*)magicWord, "cub") == 0) {
		return CUB;
	}

	return UNKNOWN;
}

/**
 * Extracts raw data from a STEX file. Takes a file descriptor and extracts / decompresses
 * the lz4 contents. Then writes the decompressed data to the output file.
 *
 * An improvement here would be to read the expanded file size from the STEX
 * header and use that dynamically instead of TEXTURE_FILESIZE.
 */
void convertSTEX(FILE* fd, string outFile) {
	// Go to the end of the file and read the number of
	// bytes. This is the file length.
	fseek(fd, 0, SEEK_END);
	int length = ftell(fd);

	char *inputBuffer = new char[length];

	// Go to the compressed data section of the STEX file.
	// The data section starts at address 0x24
	fseek(fd, 36, SEEK_SET);

	cout << "Reading STEX file of length: " << length << '\n';

	// Read the rest of the file, starting from 0x24
	int bytesRead = fread(inputBuffer, sizeof(char), length, fd);

	cout << "Read bytes from STEX file: " << bytesRead << "\n";

	char *destBuffer = new char[TEXTURE_FILESIZE];
	// The meat of this function. See: https://github.com/lz4/lz4/blob/dev/lib/lz4.h
	LZ4_decompress_safe_partial(inputBuffer,destBuffer,bytesRead, TEXTURE_FILESIZE, TEXTURE_FILESIZE );

	FILE* outHandle = fopen(outFile.c_str(), "wb");

	int write = fwrite(destBuffer, sizeof(char), TEXTURE_FILESIZE, outHandle);

	cout << "Wrote to file: " << outFile << ", total bytes: " << write << "\n";
	fclose(outHandle);

	return;
}

/**
 * Extracts data from a CUB archive. CUB archives are XOR'd so we must XOR again by the same key.
 * After reading the header we XOR the table of contents and then the individual files as well.
 */
void extractCUB(FILE* fd, string outFolder) {
	// STEP 1: Read the CUB header
	CUB_HDR header;

	fread(&header, sizeof(header), 1, fd);

	char *pStruct = (char*)&header;
	for (int i = 0; i < sizeof(header); i++){
		*(pStruct + i) ^= XOR_KEY;
	}

	cout << "Read a CUB file with the header:\n";
	cout << "Magic Word: " << header.cubHeader << '\n';
	cout << "Version: " << header.version << '\n';
	cout << "Size: " << int(header.entryCount) << '\n';
	cout << "Comment: " << header.headerComment << '\n';

	// STEP 2: Read the Table of Contents
	unsigned long tocLength = int(header.entryCount) * sizeof(CUB_ENTRY_1_1);

	unsigned char *tocBuffer = new unsigned char[tocLength];
	fread(tocBuffer, tocLength, 1, fd);
	for (unsigned long i = 0; i < tocLength; i++){
		*(tocBuffer + i) ^= XOR_KEY;
	}

	unsigned long extractedCount = 0;

	// STEP 3: For each file, extract that file.
	do {
		int length = 0, offset = 0;
		string filename;
		// There is slightly different behavior between version 1.0 and 1.1 of CUB.
		if(strcmp(header.version, "1.1") == 0) {
			CUB_ENTRY_1_1 entry;
			memcpy(&entry, tocBuffer + (extractedCount * sizeof(CUB_ENTRY_1_1)), sizeof(CUB_ENTRY_1_1));

			length = entry.length;
			offset = entry.offset;
			stringstream s;
			s << entry.filename;
			filename = s.str();
		}
		else if(strcmp(header.version, "1.0") == 0) {
			CUB_ENTRY_1_0 entry;
			memcpy(&entry, tocBuffer + (extractedCount * sizeof(CUB_ENTRY_1_0)), sizeof(CUB_ENTRY_1_0));

			length += entry.length[0] | (entry.length[1]<<8) | (entry.length[2]<<16) | (entry.length[3]<<24);
			offset += entry.offset[0] | (entry.offset[1]<<8) | (entry.offset[2]<<16) | (entry.offset[3]<<24);
			stringstream s;
			s << entry.filename;
			filename = s.str();
		}
		else {
			// Actually if you find a version you don't recognize, feel free to add a case to
			// one of the above if statements and try to open it.
			cout << "Attempting to read a CUB file of unknown version: " << header.version << '\n';
			exit(-1);
		}

		cout << filename << ", offset: " << offset << ", size: " << length << '\n';

		unsigned char *fileBuffer = new unsigned char[length];
		fseek(fd, offset, SEEK_SET);

		fread(fileBuffer, 1, length, fd);

		for (unsigned long i = 0; i < length; i++){
			*(fileBuffer + i) ^= XOR_KEY;
		}

		string outPath = outFolder;
		outPath.append(filename);

		FILE* outHandle = fopen(outPath.c_str(), "wb");

		fwrite(fileBuffer, 1, length, outHandle);
		fclose(outHandle);

		delete[] fileBuffer;

		extractedCount++;
	} while (extractedCount < header.entryCount);

	fclose(fd);

	cout << "Extracted files: " << extractedCount << '\n';

	return;
}

/**
 * Takes in a file path in argv and determines if it's a CUB or STEX file. From there, will
 * either attempt to extract files from a CUB or raw texture data from a STEX.
 */
int main(int argc, char** argv){

	char* inFilename = argv[1];
	cout << "Attempting to read: " << inFilename << '\n';

	FILE* fd;
	fd = fopen(inFilename, "rb");
	if (fd == NULL){
		cout << "Cannot open file: " << inFilename << '\n';
		exit(-1);
	}

	// Detect file type and route appropriately.
	FILE_TYPE fileType = getFileType(fd);
	if(fileType == STEX) {
		// Create the output filename. Will be the input filename
		// but with the .raw extension.
		string filename = inFilename;
		int index = filename.find_last_of('.');
		string outFilename = filename.substr(0, index);
		outFilename.append(".raw");

		convertSTEX(fd, outFilename);
	}
	else if(fileType == CUB) {
		// Create the output folder. Will be the name of the .cub
		// as a folder.
		string filePath = inFilename;
		int index = filePath.find_last_of('.');
		string outFolder = filePath.substr(0, index);
		outFolder.append("/");
		mkdir(outFolder.c_str(), 0777);

		extractCUB(fd, outFolder);
	}
	else {
		cout << "Attempted to process a file of unknown type.\n";
		exit(-1);
	}

	cout << "Completed processing file: " << inFilename << '\n';

	return 0;
}
