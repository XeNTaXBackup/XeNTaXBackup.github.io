F1 Manager 2000 RFD compression (cmp1)
By Elbereth

This is the result of my investigation regarding the RFC/RFH/RFD file formats for type 1 compression entries.
Esto es el resultado de mi investigacion del formato de entradas de los RFC/RFH/RFD con compresion tipo 1.

Looks like a Huffman compression:
Parece ser compresion Huffman:

   0    4 bytes    Uncompressed size (x)   Tama�o original (descomprimido)
   4    1 bytes    Max frequency? Frequencia maxima?
   5    1 bytes    Init frequency? Frequencia initial? 
   6 1026 bytes    Empty / Vacio (00)
1032 1024 bytes    Dictionnary / Diccionario
                     (word 1 byte + type 1 byte [0 or 1]) / (caracter 1 byte + tipo 1 byte [0 o 1])
					 (if the type is 1, increase current frequency, word is meaningless) / (si el tipo es 1, incrementar la frequencia actual, el caracter no tiene sentido en este caso)
					 (if the type is 0, keep word with current frequency) / (si el tipo es 0, guardar el caracter con la frequencia actual)
2056    y bytes    Compressed data expanding to x bytes (Huffman with frequency table as described?)
                   Dataos comprimidos que se descomprimen como x bytes (Huffman con la tabla de frequencia descrita?)

